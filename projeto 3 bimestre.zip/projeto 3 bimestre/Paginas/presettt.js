const canvas = document.getElementById("magicCanvas");
const ctx = canvas.getContext("2d");
console.log("Efeito mágico iniciado!");

let particles = [];
let mouse = {
    x: null,
    y: null,
    active: false
};

const particleCount = 90;
const maxDistance = 120;
const mouseRadius = 160;

function resizeCanvas() {
    const dpr = window.devicePixelRatio || 1;

    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;

    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

resizeCanvas();
window.addEventListener("resize", () => {
    resizeCanvas();
    initializeParticles(); // Opcional: reinicializa para ajustar ao novo tamanho
});

function createParticle(x, y) {
    return {
        x: x,
        y: y,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        size: Math.random() * 1.8 + 0.7
    };
}

function initializeParticles() {
    particles = [];

    for (let i = 0; i < particleCount; i++) {
        particles.push(
            createParticle(
                Math.random() * window.innerWidth,
                Math.random() * window.innerHeight
            )
        );
    }
}

initializeParticles();

window.addEventListener("mousemove", function(event) {
    mouse.x = event.clientX;
    mouse.y = event.clientY;
    mouse.active = true;
});

window.addEventListener("mouseout", function(event) {
    if (!event.relatedTarget) {
        mouse.active = false;
    }
});

window.addEventListener("touchmove", function(event) {
    const touch = event.touches[0];

    mouse.x = touch.clientX;
    mouse.y = touch.clientY;
    mouse.active = true;
}, { passive: true });

window.addEventListener("touchend", function() {
    mouse.active = false;
});

function drawLine(x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < maxDistance) {
        // CORRIGIDO: Adicionado o operador de subtração e divisão correto
        const opacity = 1 - (dist / maxDistance);

        ctx.strokeStyle = `rgba(218, 165, 32, ${opacity})`;

        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }
}

function drawParticle(p) {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);

    ctx.fillStyle = "rgba(255, 255, 255, 0.95)";
    ctx.shadowBlur = 7;
    ctx.shadowColor = "#ffffff";
    ctx.fill();

    ctx.shadowBlur = 0;
}

function animate() {
    ctx.clearRect(
        0, 0,
        window.innerWidth,
        window.innerHeight
    );

    for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > window.innerWidth) {
            p.vx *= -1;
        }

        if (p.y < 0 || p.y > window.innerHeight) {
            p.vy *= -1;
        }

        if (mouse.active && mouse.x !== null) {
            const dx = mouse.x - p.x;
            const dy = mouse.y - p.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            if (distance < mouseRadius && distance > 0) {
                // CORRIGIDO: Adicionado o operador de subtração e divisão correto
                const force = (1 - (distance / mouseRadius)) * 1;

                p.vx += (dx / distance) * force;
                p.vy += (dy / distance) * force;
            }
        }

        p.vx *= 1.05;
        p.vy *= 1.05;

        const speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);

        if (speed > 1.2) {
            p.vx = (p.vx / speed) * 1.2;
            p.vy = (p.vy / speed) * 1.2;
        }
    }

    for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
            drawLine(
                particles[i].x,
                particles[i].y,
                particles[j].x,
                particles[j].y
            );
        }
    }

    for (const p of particles) {
        drawParticle(p);
    }

    requestAnimationFrame(animate);
}

animate();
